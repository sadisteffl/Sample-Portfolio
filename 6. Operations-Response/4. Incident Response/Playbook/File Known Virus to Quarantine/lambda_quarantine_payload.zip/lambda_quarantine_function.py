import boto3
import json
import os
from botocore.exceptions import ClientError

s3 = boto3.client('s3')
SOURCE_BUCKET = os.environ['SOURCE_BUCKET']
QUARANTINE_BUCKET = os.environ['QUARANTINE_BUCKET']

def lambda_handler(event, context):
    """
    Move an infected file from source bucket to quarantine bucket
    """
    try:
        # Extract file information from Step Functions input
        bucket = event.get('bucket', SOURCE_BUCKET)
        key = event.get('objectKey')

        if not bucket or not key:
            raise ValueError("Missing bucket or key in event")

        print(f"Quarantining file: s3://{bucket}/{key}")
        print(f"Full event: {json.dumps(event)}")

        # Check if object exists before copying
        try:
            head_obj = s3.head_object(Bucket=bucket, Key=key)
            print(f"Object found. Size: {head_obj.get('ContentLength')}, Tags: {head_obj.get('TagCount')}")
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code')
            if error_code == '404' or 'NoSuchKey' in str(e):
                print(f"ERROR: Object s3://{bucket}/{key} does not exist!")
                print(f"File may have already been moved or deleted")
                raise FileNotFoundError(f"Object {key} not found in bucket {bucket}")
            else:
                raise

        # Copy object to quarantine bucket
        copy_source = {'Bucket': bucket, 'Key': key}
        s3.copy_object(CopySource=copy_source, Bucket=QUARANTINE_BUCKET, Key=key)

        print(f"Successfully copied to quarantine: s3://{QUARANTINE_BUCKET}/{key}")

        # Delete from source
        s3.delete_object(Bucket=bucket, Key=key)

        print(f"Deleted from source: s3://{bucket}/{key}")

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'File quarantined successfully',
                'source': f's3://{bucket}/{key}',
                'quarantine': f's3://{QUARANTINE_BUCKET}/{key}'
            })
        }

    except FileNotFoundError as e:
        print(f"File not found error: {e}")
        raise e
    except ClientError as e:
        print(f"Error quarantining file: {e}")
        raise e
    except Exception as e:
        print(f"Unexpected error: {e}")
        raise e
